^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package turtlebot3_autorace_mission
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.2.1 (2025-02-26)
------------------
* Support for ROS 2 Humble version
* Renewal of package structure and functionality
* New update for the construction mission algorithm
* Contributors: ChanHyeong Lee, Hyungyu Kim, Jun

1.2.0 (2019-02-07)
------------------
* modified for gazebo mode
* added node_mission
* added travis for ROS Melodic version
* updated the CHANGELOG and version to release binary packages
* Contributors: Gilbert, Pyo

1.1.0 (2018-05-30)
------------------
* modified system configuration related with the .py extensions & core launch launches
* merged pull request `#4 <https://github.com/ROBOTIS-GIT/turtlebot3_autorace/issues/4>`_ `#3 <https://github.com/ROBOTIS-GIT/turtlebot3_autorace/issues/3>`_ `#2 <https://github.com/ROBOTIS-GIT/turtlebot3_autorace/issues/2>`_
* Contributors: Leon Jung, Pyo

1.0.0 (2018-03-20)
------------------
* refactoring to release
* fixed the dependencies
* updated control_parking.py
* first upload of turtlebot3_autorace
* Contributors: Leon Jung, Pyo
